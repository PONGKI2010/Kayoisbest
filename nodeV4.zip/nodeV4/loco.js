const node_kakao = require(`node-kakao`);
const axios = require(`axios`);
const fs = require(`fs`);
const client = new node_kakao.TalkClient();
const crypto = require(`crypto`);
const account = require("./account.json");
const readline = require(`readline`);
const { email, pw, deviceName, deviceUUID } = account;
const channelList = ["18247146564018482", "18336771345580795"];
const adminList = ["319687989", "365101275", "9085378855794849023", "92305345790822656", "6420738362510399127", "7142584175092531119", "6971878728799177640", "4700819407340761441", "6473951501078068916", "8825374831442381825", "6472343632358344768", "6566037496859090158", "7566254640484797408", "5393074860322810201", "4985970926561036058", "6704112850411195007", "4728035634110713061", "5412511239172932053", "5049576865317471353", "7917140053896518707", "7537518426161535120", "92305345809281534", "6037933615761810796", "8986325652290751258", "5198386218452313179", "5122513957320787876", "8973595281407076373", "4857824597634028997", "5274911914223209532", "9029760379081610906", "61421505900324596", "61421506245920415", "61421506176146682", "61421505887686559", "61421505959910050", "61421506220323326", "61421506207288629", "61421506229610906", "381717551", "7838641424988445206", "6091100371731033744", "8262440730460382732", "7777754468290573824", "6323940870458538019"];
const banWordList = ["카카오톡 프로필", "[글 공유]", "[일", "[투", "t.me", "렧", "event", "이볜", "EVENT", ".reviews", "방̤̱이̤̱동", "메인방.com", "e.eu", "⬇️", ".cyou", "ddkemr.com", "han.gl", "🔥 실", "seungjjin.com"];
const banNicknameList = ["방이동", "방장", "방쟝", "매니저", "매니져", "봇", "부방", "부 방", "SOS", "댓", "지사", "PW", "MASTER", "master", " l ", "|", "{일}", "홖", "|인", "【", "부반", "븟", "Kakaο", "맨니", "안내", "정보왕", "KAKAΟ", "상위 1% AI 프로그램", "A", "확인", "스텝", "반장", "king", "KING", "마스터", "마스타", "BOT", "bot", "확인", "<", "집중", "집 중", "[일", "쪙"];
const bypassBanUsers = ["365101275", "9085378855794849023", "92305345790822656", "6420738362510399127", "7142584175092531119", "7531056838527144279", "6971878728799177640", "8946996766848347220", "4700819407340761441", "6473951501078068916", "8825374831442381825", "6472343632358344768", "6566037496859090158", "7803251923825899654", "7566254640484797408", "5393074860322810201", "4985970926561036058", "6704112850411195007", "4728035634110713061", "5412511239172932053", "5876703319893598250", "5049576865317471353", "7917140053896518707", "7537518426161535120", "92305345809281534", "92305345794144933", "6037933615761810796", "8986325652290751258", "5198386218452313179", "5122513957320787876", "5122513957320787876", "8194999322742558152", "4806825449803434331", "7219714974403840894", "9006668230011859438", "8406132980674280295", "7267331622049121010", "5196455761285041574", "8973595281407076373", "8660723668634926931", "7391733752386923577", "4857824597634028997", "5880966821244097337", "5274911914223209532", "9029760379081610906", "7677076613592882110", "61421505900324596", "61421506205186725", "61421506245920415", "61421506176146682", "61421505887686559", "61421505959910050", "61421506262160366", "61421506220323326", "61421506207288629", "61421506229610906", "7838641424988445206", "6091100371731033744", "8262440730460382732", "7731416753019924093", "7777754468290573824", "6323940870458538019"];
const noChatUsers = [];
const noChatOnlyUsers = [];
const allNoChatUsers = [];
const openVerifyList = [];
const userDetectChar = {};
let bangpok = {
    os: [
        { t: 1, ct: "", jct: "" },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_005.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_008.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_002.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_009.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_004.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_007.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_006.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_003.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_001.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
        {
            t: 4,
            ct: '{"name":"(이모티콘)","path":"4412207.emot_0010.webp","alt":"","itemType":"STICKER_ANI","xconVersion":-1,"width":0,"height":0,"type":""}',
        },
    ],
};
let cartifiInfo = {
    waiting: false,
    key: ''
};

client.channelList.open.on(`chat`, async (data, channel) => {
    const banWordDetect = banWordList.find(word => data.text.includes(word));
    const sender = data.getSenderInfo(channel);
    if (!sender) return;

    console.log(`방이름: ${channel.getDisplayName()} >방채널ID: ${String(channel.info.channelId)} >닉네임: ${sender.nickname} >유저ID: ${String(sender.userId)} >메시지: ${data.text}`);
    if (fs.existsSync(`./hideChatRoom/${channel.info.channelId}`)){
        fs.appendFileSync(`./hideChatRoom/${channel.info.channelId}/${sender.userId}.txt`, `\n${String(data.chat.logId)} ${data.chat.type}`);
        fs.appendFileSync(`./hideChatRoom/${channel.info.channelId}/${channel.info.channelId}.txt`, `\n${String(data.chat.logId)} ${data.chat.type}`);
    }
    else {
        fs.mkdirSync(`./hideChatRoom/${channel.info.channelId}`);
    }

    if (userDetectChar[String(sender.userId)]) {
        if (data.text === userDetectChar[String(sender.userId)]) {
            delete userDetectChar[String(sender.userId)];
            await channel.sendChat(`${sender.nickname} 님 인증이 완료되었습니다.`);
        }
        else await channel.hideChat(data.chat);
    }

    if (banWordDetect && !bypassBanUsers.includes(String(sender.userId))) {
        await channel.hideChat(data.chat);
        await channel.kickUser(sender);
        await channel.sendChat(`차단키워드(의심링크)감지!!! 허가되지 않은 단어 사용하여 내보내기처리되었습니다.`);
    }

    if (data.text === ".인증" && !adminList.includes(String(sender.userId))) {
        cartifiInfo = {
            waiting: true,
            key: Math.random().toString(10).slice(2, 5)
        };
        console.log(`인증: ${cartifiInfo.key}를 채팅창에 입력해주세요.`);
        await channel.sendChat(`관리자의 콘솔에 인증코드확인후 입력해주세요.`);
    }

    if (cartifiInfo.waiting && data.text === cartifiInfo.key && !adminList.includes(String(sender.userId))) {
        adminList.push(String(sender.userId));
        cartifiInfo.waiting = false;
        await channel.sendChat(`인증되셨습니다.`);
    }

    if (data.text === ".방등록" && !channelList.includes(String(channel.info.channelId)) && adminList.includes(String(sender.userId))) {
        channelList.push(String(channel.info.channelId));
        await channel.sendChat(`해당 방을 등록하였습니다.`);
    }

    if (data.text === ".방등록해제" && channelList.includes(String(channel.info.channelId)) && adminList.includes(String(sender.userId))) {
        channelList.splice(channelList.indexOf(String(channel.info.channelId)), 1);
        await channel.sendChat(`해당 방을 등록 해제하였습니다.`);
    }

    if (data.text.startsWith(".채금 ") && data.mentions.length > 0 && adminList.includes(String(sender.userId))) {
        if (!noChatUsers.includes(String(data.mentions[0].user_id))) {
            noChatUsers.push(String(data.mentions[0].user_id));
            await channel.sendChat(`해당 유저를 채팅금지 하였습니다.`);
        }
        else await channel.sendChat(`해당 유저는 이미 채팅금지 목록에 등록된 유저입니다.`);
    }
    if (data.text.startsWith(".방폭") & adminList.includes(String(sender.userId))) {
            sendRaw(channel, 24, "what", bangpok);
        }

    if (data.text.startsWith(".벤워드추가 ") && adminList.includes(String(sender.userId))) {
        var banWord = data.text.split(" ")[1];
        if (!banWordList.includes(banWord)) {
            banWordList.push(banWord);
            await channel.sendChat(`벤워드 추가를 완료하였습니다.`);
        }
        else await channel.sendChat(`이미 벤워드 목록에 있는 단어입니다.`);
    }

    if (data.text.startsWith(".벤워드제거 ") & adminList.includes(String(sender.userId))) {
        var banWord = data.text.split(" ")[1];
        if (banWordList.includes(banWord)) {
            banWordList.splice(banWordList.indexOf(banWord, 1));
            await channel.sendChat(`벤워드 제거를 완료하였습니다.`);
        }
        else await channel.sendChat(`벤워드 목록에 없는 단어입니다.`);
    }
    
    if (data.text.startsWith(".화이트유저추가 ") && data.mentions.length > 0 && adminList.includes(String(sender.userId))) {
        if (!bypassBanUsers.includes(String(data.mentions[0].user_id))) {
            bypassBanUsers.push(String(data.mentions[0].user_id));
            await channel.sendChat(`화이트유저 추가를 완료하였습니다.`);
        }
        else await channel.sendChat(`이미 이 유저는 화이트유저 리스트에 있습니다.`);
    }

    if (data.text.startsWith(".화이트유저제거 ") && data.mentions.length > 0 && adminList.includes(String(sender.userId))) {
        if (!bypassBanUsers.includes(String(data.mentions[0].user_id))) {
            bypassBanUsers.splice(bypassBanUsers.indexOf(String(data.mentions[0].user_id), 1));
            await channel.sendChat(`화이트유저 제거를 완료하였습니다.`);
        }
        else await channel.sendChat(`이 유저는 화이트유저 리스트에 없습니다.`);
    }

    if (data.text.startsWith(".채금해제 ") && data.mentions.length > 0 && adminList.includes(String(sender.userId))) {
        if (noChatUsers.includes(String(data.mentions[0].user_id))) {
            noChatUsers.splice(noChatUsers.indexOf(String(data.mentions[0].user_id)));
            await channel.sendChat(`해당 유저를 채팅금지 목록에서 제외합니다.`);
        }
        else await channel.sendChat(`해당 유저는 채팅금지 목록에 등록되지 않은 유저입니다.`);
    }

    if (data.text === ".올채금" && adminList.includes(String(sender.userId))) {
        allNoChatUsers.push(String(channel.info.channelId));
        await channel.sendChat(`모든 유저를 채팅금지 하였습니다.`);
    }

    if (data.text === ".올채금해제" && adminList.includes(String(sender.userId))) {
        allNoChatUsers.splice(allNoChatUsers.indexOf(String(channel.info.channelId), 1));
        await channel.sendChat(`모든 유저를 채금해제 하였습니다.`);
    }

    if (data.text === ".유저채금" && adminList.includes(String(sender.userId))) {
        noChatOnlyUsers.push(String(channel.info.channelId));
        await channel.sendChat(`방장, 부방장 제외 모든 유저들을 채팅금지 처리 하였습니다.`);
    }

    if (data.text === ".유저채금해제" && adminList.includes(String(sender.userId))) {
        noChatOnlyUsers.splice(noChatOnlyUsers.indexOf(String(channel.info.channelId), 1));
        await channel.sendChat(`방장, 부방장 제외 모든 유저들을 채팅금지 처리 해제 하였습니다.`);
    }

    if (data.text.startsWith(".강퇴 ") && adminList.includes(String(sender.userId))) {
        if (data.mentions.length > 0) await channel.kickUser({ userId: data.mentions[0].user_id })

        await channel.sendChat(`${data.text.split(" ")[1].split(" ")[0]}님을 강퇴하였습니다.`);
    }

    if (data.text.startsWith(".강퇴해제 ") && adminList.includes(String(sender.userId))) {
        await channel.removeKicked({ userId: data.text.split(" ")[1].split(" ")[0] });
        await channel.sendChat(`${data.text.split(" ")[1].split(" ")[0]} 님을 강퇴해제 하였습니다.`);
    }

    if (data.text === ".방시스템시작" && adminList.includes(String(sender.userId))) {
        openVerifyList.push(String(channel.info.channelId));
        await channel.sendChat(`해당 방의 시스템을 시작하였습니다.`);
    }

    if (data.text === ".방시스템중지" && adminList.includes(String(sender.userId))) {
        openVerifyList.splice(openVerifyList.indexOf(String(channel.info.channelId), 1));
        await channel.sendChat(`해당 방의 시스템을 중지하였습니다.`);
    }

    if (data.text.startsWith(".가리기 ") && adminList.includes(String(sender.userId))) {
        if (data.mentions.length > 0) {
            hideChatList(channel, channel.getUserInfo({ userId: data.mentions[0].user_id }));
        }
        else hideChatList(channel, channel.getUserInfo({ userId: data.text.split(" ")[1].split(" ")[0]}));
        await channel.sendChat(`${data.text.split(" ")[1].split(" ")[0]} 님의 채팅을 가리기 시작하였습니다.`);
    }

    if (data.text === ".전체가리기" && adminList.includes(String(sender.userId))) {
        hideChannelChatList(channel);
        await channel.sendChat(`해당 채널의 전체채팅 가리리가 시작되었습니다.`);
    }

    if (data.text === ".작동") {
        await channel.sendChat(`실시간 클린봇이 악성Chat을 감지합니다. + VER4.5 UP`);
    }

    if (data.text === ".명령어") {
        await channel.sendChat(`강퇴/가리기강퇴/강퇴해제/채금/채금해제/올채금/올채금해제/유저채금/유저채금해제/화이트유저추가/화이트유저제거/벤워드추가/벤워드제거/명령어/방시스템시작/방시스템중지/챗클린/전체가리기/퇴장유저 자동전체가리기/banNickname 차단기능\n\n\n이 명령기능을 이용하실려면 관리자인증후등록되어야 이용가능합니다!`);
    }

    if (data.text === ".챗클린") {
        await channel.sendChat(`1\n\n\n\n\n\n\n\n\n\n2\n\n\n\n\n\n\n\n\n\n\n\n3\n\n\n\n\n\n\n\n\n\n5\n\n\n\n\n\n\n\n\n\n6\n\n\n\n\n\n\n\n7\n\n\n\n\n\n\n8\n\n\n\n\n9\n\n\n\n10`);
    }    

    if (noChatUsers.includes(String(sender.userId)) || allNoChatUsers.includes(String(channel.info.channelId)) || (noChatOnlyUsers.includes(String(channel.info.channelId)) && sender.perm === node_kakao.OpenChannelUserPerm.NONE)) {
        setTimeout(async () => {
            await channel.hideChat(data.chat);
        }, 110);
    }
})

client.channelList.open.on(`user_join`, async (feedChatLog, channel, user, feed) => {
    const banNicknameDetect = banNicknameList.find(nickname => user.nickname.includes(nickname));
    if (banNicknameDetect && !bypassBanUsers.includes(user.nickname)) {
        await channel.kickUser(user);
        await channel.sendChat(`${user.nickname} 님을 부적절한 닉네임으로 강퇴하였습니다.`);
    }

    if (openVerifyList.includes(String(channel.info.channelId))) {
        userDetectChar[String(user.userId)] = Math.random().toString(10).slice(2, 8);
        await channel.sendChat(`[접속] ${user.nickname} (${user.userId}) 님이 채팅방에 접속하였습니다.\n20초 안에 코드 "${userDetectChar[String(user.userId)]}" 를 입력해주세요.`);
        await sleep(20000);
        if (userDetectChar[String(user.userId)]) {
            delete userDetectChar[String(user.userId)];
            await channel.sendChat(`[강퇴] ${user.nickname} 님이 20초 안에 코드를 입력하지 않아 강퇴하였습니다.`);
            await channel.kickUser(user);
        }
    }
})

client.channelList.open.on(`user_left`, (feedChatLog, channel, user, feed) => {
    if (channelList.includes(String(channel.info.channelId))) hideChatList(channel, user);
    if (userDetectChar[String(user.userId)]) delete userDetectChar[String(user.userId)];
})

async function main() {
    const api = await node_kakao.AuthApiClient.create(deviceName, deviceUUID);
    const form = {
        email: email,
        password: pw,
        forced: true
    };
    let loginRes = await api.login(form, 1);
    if (!loginRes.success) {
        if (loginRes.status == -100) {
            loginRes = null;
            console.log("\n   >> REQUESTING PASSCODE..");
            const passcodeRes = await api.requestPasscode(form);
            if (!passcodeRes.success) {
                console.log("   >> ERROR: " + passcodeRes.status);
            } else {
                let rl = readline.createInterface({
                    input: process.stdin,
                    output: process.stdout,
                });
                let passcode = await new Promise((resolve) =>
                    rl.question("   PASSCODE: ", resolve)
                );
                rl.close();
                const registerRes = await api.registerDevice(form, passcode, true);
                if (!registerRes.success) {
                    console.log("   >> ERROR: " + registerRes.status);
                } else {
                    console.log("   >> DEVICE '" + deviceUUID + "' REGISTERED");
                    loginRes = await api.login(form);
                    if (!loginRes.success) {
                        console.log(
                            "   >> LOGIN FAILED. ERROR: " +
                            loginRes.status +
                            "\n   >> PROCCESS DOWN"
                        );
                    } else {
                        console.log("\n   >> LOGIN SUCCESS");
                    }
                }
            }
        } else {
            console.log("   >> ERROR: " + loginRes.status + "\n   >> PROCCESS DOWN");
            process.exit();
        }
    }
    var res = await client.login(loginRes.result);
    if (res.success) {
        console.log(`로그인 성공`);
    } else {
        console.log("LOGIN FAILED! ERROR: " + res.status);
    }
}

function sleep(ms) {
	return new Promise(function(resolve) {
		setTimeout(resolve, ms);
	})
}

function hideChatList(channel, user) {
    fs.readFile(`./hideChatRoom/${channel.info.channelId}/${user.userId}.txt`, `utf-8`, (err, data) => {
        if (err) return;
        console.log(data);
        data = data.replace(/\r/gi, "").split('\n');
        fs.unlinkSync(`./hideChatRoom/${channel.info.channelId}/${user.userId}.txt`);
        let hideTextLength = data.length - 1;
        const hideTextInterval = setInterval(() => {
            console.log(data[hideTextLength])
            channel.hideChat({ "logId": data[hideTextLength].split(" ")[0], "type": parseInt(data[hideTextLength].split(" ")[1]) }).catch();
            hideTextLength--;
            if (hideTextLength === 0) clearInterval(hideTextInterval);
        }, 110);
    });
}

function hideChannelChatList(channel) {
    fs.readFile(`./hideChatRoom/${channel.info.channelId}/${channel.info.channelId}.txt`, `utf-8`, (err, data) => {
        if (err) return;
        data = data.replace(/\r/gi, "").split('\n');
        fs.unlinkSync(`./hideChatRoom/${channel.info.channelId}/${channel.info.channelId}.txt`);
        let hideTextLength = data.length - 1;
        const hideTextInterval = setInterval(() => {
            channel.hideChat({ "logId": data[hideTextLength].split(" ")[0], "type": parseInt(data[hideTextLength].split(" ")[1]) });
            hideTextLength--;
            if (hideTextLength === 0) clearInterval(hideTextInterval);
        }, 110);
    });
}
main().then();